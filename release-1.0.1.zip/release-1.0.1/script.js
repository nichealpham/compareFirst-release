﻿function raiseSearchProductEvent() {
    var catg = '';
    var act = $('.products-tab li.tab-active').attr('id');
    if (act != 'endow') {
        if (act == 'bips') {
            catg = $('.bips-option li.selected').attr('data-id');
        } else if (act == 'term' || act == 'whole') {
            catg = $('.selCatg-life li.selected').attr('data-id');
        }
    } else {
        catg = 'z';
    }
    var selectedSubGroup = catg;
    var selectedGender = $('.gender li.selected').attr('data-id');
    var selectedSmokerStatus = $('.smoker li.selected').attr('data-id');
    var selectedCIRider = $('#illness-benefit li.selected').attr('data-id');

    $('#prodGroup').val(act);
    $('#selCategory').val(selectedSubGroup);
    $('#pageAction').val('search');
    $('#selGender').val(selectedGender);
    $('#selSmokStatus').val(selectedSmokerStatus);
    $('#selCIRider').val(selectedCIRider);
    $('#prodGroupForm').attr('method', 'post');
    $('#prodGroupForm').attr('action', 'searchProductsEvent.action');
    //$('#prodGroupForm').submit();

    showLoading(true);

    $.ajax({
        type: 'POST',
        url: 'http://comparefirst.sg/wap/searchProductsEvent.action',
        //Add the request header
        headers: {
            'Host': 'comparefirst.sg',
            'Connection': 'keep-alive',
            'Content-Length': 840,
            'Cache-Control': 'max-age=0',
            'Origin': 'http://comparefirst.sg',
            'Upgrade-Insecure-Requests': 1,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'http://comparefirst.sg/wap/homeEvent.action',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'vi-VN,vi;q=0.8,fr-FR;q=0.6,fr;q=0.4,en-US;q=0.2,en;q=0.2,es;q=0.2,tr;q=0.2',
        },
        contentType: 'application/x-www-form-urlencoded',

        //Add form data
        data: $('#prodGroupForm').serialize(),
        success: function (response) {
            document.open("text/html", "replace");
            document.write(response);
            document.close();
        },
        error: function (xhr, status, error) {
            alert(xhr.responseText);
        }
    }); //End of Ajax
}

function controlElements() {
    if ($('#headerForm')[0].style.display !== 'none')
        $('#headerForm').hide();

    if ($('footer')[0].style.display !== 'none')
        $('footer').hide();

    if ($('.search-criteria')[0].style.display !== 'block')
        $('#colExp').click();

    if ($('#result-crawl').length === 0) {
        var ele = document.createElement('DIV');
        ele.id = 'result-crawl';
        ele.setAttribute('title', 'Data');
        ele.style.display = 'none';
        document.body.appendChild(ele);
    }

    if ($('.cssload-container').length === 0)
        $('body').append('<div class="cssload-container"><div class="cssload-whirlpool"></div></div>');
}

function getDataCrawl() {
    var xmlUrl = $('#prodStringXML').val();
    var prodgroup = $('#prodGroup').val();
    
    if (xmlUrl) {
        searchResultXml(prodgroup, xmlUrl);

        $('#result-crawl').html('<textarea rows=27 cols=115>' + JSON.stringify(data, null, 2) + '</textarea>');
        $('#result-crawl').dialog({
            maxWidth: 810,
            maxHeight: 510,
            width: 810,
            height: 510,
            modal: true
        });
    }
}

var timeout;

function saveDataCrawl() {
    showLoading(true);

    clearTimeout(timeout);
    timeout = setTimeout(function () {
        showLoading(false);
    }, 10000);
    
    //alert('Developing....');

    if (data && data.length > 0)
        sendData(data, 0);
}

function showLoading(isShow) {
    if (isShow) {
        $('body').addClass('background-loading');
        $('.cssload-container').show();
    }
    else {
        $('body').removeClass('background-loading');
        $('.cssload-container').hide();
    }
}

function sendData(arr, index) {
    var d = parseDataCrawl(arr[index]);
    
    $.ajax({
        type: 'POST',
        url: 'http://13.228.111.11/api/product/add',
        dataType: 'json',
        contentType: 'application/json; charset=utf-8',
        data: JSON.stringify(d),
        success: function (response) {
            if (arr.length > index + 1)
                setTimeout(function() { sendData(arr, index + 1) }, 100);
            else {
                showLoading(false);
                alert('Success!');
            }
        },
        error: function (xhr, status, error) {
            alert(error);
        }
    }); //End of Ajax
}

function getDataResponse() {
    var d = [];

    if (data && data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            d.push(parseDataCrawl(data[i]));
        }
    }

    return JSON.stringify(d);
}

function parseDataCrawl(item) {
    if (!item)
        return null;

    var premiumType;

    var temps = $('.premiumType .select2-container');
    if (temps && temps.length > 0) {
        for (var i = 0; i < temps.length; i++) {
            if (temps[i].style.display !== 'none') {
                var id = $(temps[i]).attr('id').split('_')[1];
                premiumType = document.getElementById(id);
                break;
            }
        }
    }

    var date = $('#date').val();
    var age;
    if (date && date.split('/').length === 3)
        age = new Date().getFullYear() - Number(date.split('/')[2]);
    
    return {
        insurerId: item.sInsurerId,
        insurer: item.sInsurer,
        image: item.sImage,
        productId: item.sProductId,
        productName: item.sProductName,
        productGroup: item.sProductGroup,
        tGPayout: item.sTGPayout,
        tNGPayout: item.sTNGPayout,
        tNGRate: item.sTNGRate,
        premiumAmt: item.sPremiumAmt,
        coverageTerm: item.sCoverageTerm,
        subCategory: item.sSubCategory,
        annualPremium: item.sAnnualPremium,
        totalPremium: item.sTotalPremium,
        yieldRateLR: item.sYieldRateLR,
        heighIllustratedRate: item.sHeighIllustratedRate,
        deathBen30Year: item.sDeathBen30Year,
        pondeathtgnghr30Year: item.upondeathtgnghr30Year,
        deathBenefitProject: item.sDeath_benefit_ng_nyrs_project,
        premiumPayPeriod: item.sPremiumPayPeriod,
        subtitle: item.sSubtitle,
        prodSummary: item.sprodSummary,
        rodBrochureUrl: item.prodBrochureUrl,
        premiumPaymentMode: item.sPremiumPaymentMode,
        nounderwritingActive: item.sprodFeatures1,
        sRSActive: item.sprodFeatures2,
        cPFActive: item.sprodFeatures3,
        levelSAActive: item.sprodFeatures4,
        renewabilityActive: item.sprodFeatures5,
        convertibilityActive: item.sprodFeatures6,
        cashActive: item.sprodFeatures7,
        sAMultiplierActive: item.sprodFeatures8,
        nonGuaranteedActive: item.sprodFeatures9,
        guaranteedLifeEventActive: item.sprodFeatures10,
        ciRideApp: item.sCiRideApp,
        tpdRideApp: item.sTpdRideApp,
        tGPayoutNum: item.sTGPayoutNum,
        premiumPayPeriodNum: item.sPremiumPayPeriodNum,
        annualPremiumNum: item.sAnnualPremiumNum,
        totalPremiumNum: item.sTotalPremiumNum,
        deathBen30YearNum: item.sDeathBen30YearNum,
        category: $('#bips-option .selected').attr('data-id'),
        age: age,
        gender: $('.gender .selected').attr('data-id') === 'M',
        smoker: $('.smoker .selected').attr('data-id') === 'Y',
        premiumType: premiumType && premiumType.value,
        sumAssured: $('#SADCIPTermAn').val(),
        criticalIllnessBenefit: $('#illness-benefit .selected').attr('data-id') === 'Y'
    };
}

setTimeout(controlElements, 800);